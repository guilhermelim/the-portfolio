import { KanbanView } from 'src/sections/kanban/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Kanban',
};

export default function KanbanPage() {
  return <KanbanView />;
}
