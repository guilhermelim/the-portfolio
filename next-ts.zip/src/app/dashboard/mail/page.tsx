import { MailView } from 'src/sections/mail/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Mail',
};

export default function MailPage() {
  return <MailView />;
}
