import { CheckoutView } from 'src/sections/checkout/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Checkout',
};

export default function CheckoutPage() {
  return <CheckoutView />;
}
