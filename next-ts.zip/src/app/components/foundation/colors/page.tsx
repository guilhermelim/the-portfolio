import { ColorsView } from 'src/sections/_examples/foundation';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Foundations: Colors',
};

export default function ColorsPage() {
  return <ColorsView />;
}
