import LabelView from 'src/sections/_examples/extra/label-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Label',
};

export default function LabelPage() {
  return <LabelView />;
}
