import FormValidationView from 'src/sections/_examples/extra/form-validation-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Form Validation',
};

export default function FormValidationPage() {
  return <FormValidationView />;
}
