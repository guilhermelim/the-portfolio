import AnimateView from 'src/sections/_examples/extra/animate-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Animate',
};

export default function AnimatePage() {
  return <AnimateView />;
}
