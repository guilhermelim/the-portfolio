import EditorView from 'src/sections/_examples/extra/editor-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Editor',
};

export default function EditorPage() {
  return <EditorView />;
}
