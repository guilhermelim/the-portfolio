import ScrollProgressView from 'src/sections/_examples/extra/scroll-progress-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Scroll Progress',
};

export default function ScrollProgressPage() {
  return <ScrollProgressView />;
}
