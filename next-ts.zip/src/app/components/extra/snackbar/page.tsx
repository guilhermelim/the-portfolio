import SnackbarView from 'src/sections/_examples/extra/snackbar-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Snackbar',
};

export default function SnackbarPage() {
  return <SnackbarView />;
}
