import OrganizationalChartView from 'src/sections/_examples/extra/organizational-chart-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Organizational Chart',
};

export default function OrganizationalChartPage() {
  return <OrganizationalChartView />;
}
