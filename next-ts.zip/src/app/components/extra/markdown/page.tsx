import MarkdownView from 'src/sections/_examples/extra/markdown-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Markdown',
};

export default function MarkdownPage() {
  return <MarkdownView />;
}
