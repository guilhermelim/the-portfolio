import CarouselView from 'src/sections/_examples/extra/carousel-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Carousel',
};

export default function CarouselPage() {
  return <CarouselView />;
}
