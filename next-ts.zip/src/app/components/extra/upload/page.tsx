import UploadView from 'src/sections/_examples/extra/upload-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Upload',
};

export default function UploadPage() {
  return <UploadView />;
}
