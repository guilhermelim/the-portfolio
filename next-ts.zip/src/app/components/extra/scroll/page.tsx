import ScrollView from 'src/sections/_examples/extra/scroll-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Scroll',
};

export default function ScrollPage() {
  return <ScrollView />;
}
