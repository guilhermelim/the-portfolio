import MapView from 'src/sections/_examples/extra/map-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Map',
};

export default function MapPage() {
  return <MapView />;
}
