import CopyToClipboardView from 'src/sections/_examples/extra/copy-to-clipboard-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Copy to Clipboard',
};

export default function CopyToClipboardPage() {
  return <CopyToClipboardView />;
}
