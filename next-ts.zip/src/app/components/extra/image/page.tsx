import ImageView from 'src/sections/_examples/extra/image-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Image',
};

export default function ImagePage() {
  return <ImageView />;
}
