import MultiLanguageView from 'src/sections/_examples/extra/multi-language-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Multi Language',
};

export default function MultiLanguagePage() {
  return <MultiLanguageView />;
}
