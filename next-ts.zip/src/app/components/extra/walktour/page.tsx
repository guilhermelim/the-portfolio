import WalktourView from 'src/sections/_examples/extra/walktour-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Walktour',
};

export default function WalktourPage() {
  return <WalktourView />;
}
