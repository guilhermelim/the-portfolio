import SwitchView from 'src/sections/_examples/mui/switch-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Switch',
};

export default function SwitchPage() {
  return <SwitchView />;
}
