import AvatarView from 'src/sections/_examples/mui/avatar-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Avatar',
};

export default function AvatarPage() {
  return <AvatarView />;
}
