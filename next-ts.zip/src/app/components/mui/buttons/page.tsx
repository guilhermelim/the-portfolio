import ButtonView from 'src/sections/_examples/mui/button-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Button',
};

export default function ButtonPage() {
  return <ButtonView />;
}
