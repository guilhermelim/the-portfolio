import TransferListView from 'src/sections/_examples/mui/transfer-list-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Transfer List',
};

export default function TransferListPage() {
  return <TransferListView />;
}
