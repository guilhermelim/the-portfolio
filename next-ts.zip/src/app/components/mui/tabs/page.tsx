import TabsView from 'src/sections/_examples/mui/tabs-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Tabs',
};

export default function TabsPage() {
  return <TabsView />;
}
