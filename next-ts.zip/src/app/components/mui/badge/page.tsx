import BadgeView from 'src/sections/_examples/mui/badge-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Badge',
};

export default function BadgePage() {
  return <BadgeView />;
}
