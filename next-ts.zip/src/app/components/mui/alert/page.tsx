import AlertView from 'src/sections/_examples/mui/alert-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Alert',
};

export default function AlertPage() {
  return <AlertView />;
}
