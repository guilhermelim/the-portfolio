import TextfieldView from 'src/sections/_examples/mui/textfield-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: TextField',
};

export default function TextfieldPage() {
  return <TextfieldView />;
}
