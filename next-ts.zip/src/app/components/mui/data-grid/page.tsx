import DataGridView from 'src/sections/_examples/mui/data-grid-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: DataGrid',
};

export default function DataGridPage() {
  return <DataGridView />;
}
