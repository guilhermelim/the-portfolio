import MenuView from 'src/sections/_examples/mui/menu-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Menu',
};

export default function MenuPage() {
  return <MenuView />;
}
