import StepperView from 'src/sections/_examples/mui/stepper-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Stepper',
};

export default function StepperPage() {
  return <StepperView />;
}
