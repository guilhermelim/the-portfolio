import RadioButtonView from 'src/sections/_examples/mui/radio-button-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Radio Button',
};

export default function RadioButtonPage() {
  return <RadioButtonView />;
}
