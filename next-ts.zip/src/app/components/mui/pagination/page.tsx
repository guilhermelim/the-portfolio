import PaginationView from 'src/sections/_examples/mui/pagination-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Pagination',
};

export default function PaginationPage() {
  return <PaginationView />;
}
