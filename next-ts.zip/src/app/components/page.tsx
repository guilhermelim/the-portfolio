import ComponentsView from 'src/sections/_examples/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components',
};

export default function ComponentsPage() {
  return <ComponentsView />;
}
