import { SupabaseVerifyView } from 'src/sections/auth/supabase';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Supabase: Verify',
};

export default function VerifyPage() {
  return <SupabaseVerifyView />;
}
