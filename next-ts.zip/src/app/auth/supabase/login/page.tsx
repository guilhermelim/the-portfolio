import { SupabaseLoginView } from 'src/sections/auth/supabase';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Supabase: Login',
};

export default function LoginPage() {
  return <SupabaseLoginView />;
}
