import { SupabaseNewPasswordView } from 'src/sections/auth/supabase';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Supabase: New Password',
};

export default function NewPasswordPage() {
  return <SupabaseNewPasswordView />;
}
