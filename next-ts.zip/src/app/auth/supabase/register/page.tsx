import { SupabaseRegisterView } from 'src/sections/auth/supabase';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Supabase: Register',
};

export default function RegisterPage() {
  return <SupabaseRegisterView />;
}
