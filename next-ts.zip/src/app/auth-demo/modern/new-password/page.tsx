import { ModernNewPasswordView } from 'src/sections/auth-demo/modern';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Modern: New Password',
};

export default function ModernNewPasswordPage() {
  return <ModernNewPasswordView />;
}
