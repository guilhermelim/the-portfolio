import { ModernRegisterView } from 'src/sections/auth-demo/modern';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Modern: Register',
};

export default function ModernRegisterPage() {
  return <ModernRegisterView />;
}
