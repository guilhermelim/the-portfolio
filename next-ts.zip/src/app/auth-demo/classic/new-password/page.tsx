import { ClassicNewPasswordView } from 'src/sections/auth-demo/classic';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Classic: New Password',
};

export default function ClassicNewPasswordPage() {
  return <ClassicNewPasswordView />;
}
