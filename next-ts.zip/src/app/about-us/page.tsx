import { AboutView } from 'src/sections/about/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'About us',
};

export default function AboutPage() {
  return <AboutView />;
}
